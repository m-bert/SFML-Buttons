#!/bin/bash

rm -rf /usr/local/share/fonts/sfml-button-font.ttf 
rm -rf  /usr/local/include/sfml-better-components
rm -rf /usr/local/lib/libsfml-better-components.a